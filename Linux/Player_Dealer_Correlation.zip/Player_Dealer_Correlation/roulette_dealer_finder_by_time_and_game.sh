

#!/bin/bash

echo "Time stamp to check: $1"
echo "4 digit date to check: $2"
echo "Name of game to check: $3"

case "$3" in

#case 1
"Black Jack") echo "\nThe black jack dealer is"
grep "$1" "$2"_Dealer_schedule | awk '{$5="";$6="";$7="";$8=""; print $0;}' ;;

#case 2
"Roulette") echo "\nThe roulette dealer is" 
grep "$1" "$2"_Dealer_schedule | awk '{$3="";$4="";$7="";$8=""; print $0;}' ;;

#case 3
"Texas Hold EM") echo "\nThe texas hold EM dealer is" 
grep "$1" "$2"_Dealer_schedule | awk '{$3="";$4="";$5="";$6=""; print $0;}' ;;

#deafualt case
	*) echo "Game not specified correctly, run again and enter Black Jack/Roulette/Texas Hold EM";;
esac


#!/bin/bash

echo "Time stamp to check: $1"
echo "4 digit date to check: $2"

grep "$1" "$2"_Dealer_schedule | awk '{$3="";$4="";$7="";$8=""; print $0;}'
